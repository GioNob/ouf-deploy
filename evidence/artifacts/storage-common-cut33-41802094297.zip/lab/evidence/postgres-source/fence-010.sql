SELECT json_build_object(
 'control',(SELECT row_to_json(c) FROM ouf_fence_lab.control c),
 'intents',(SELECT json_agg(i ORDER BY operation) FROM ouf_fence_lab.intents i),
 'events',(SELECT json_agg(e ORDER BY sequence) FROM ouf_fence_lab.events e));