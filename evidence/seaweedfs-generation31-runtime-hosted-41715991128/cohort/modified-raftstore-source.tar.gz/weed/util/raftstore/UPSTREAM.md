# OUF local Raft bbolt adapter

Derived from github.com/hashicorp/raft-boltdb/v2 v2.4.2.
Copyright and MPL-2.0 source-file notices and LICENSE are retained.

Active store operations, bucket names, MessagePack encoding, fsync defaults,
metrics and log/stable-store interfaces are unchanged from that release.
Only the unused MigrateToV2 helper and its archived boltdb/bolt import, and
that helper's upstream test, are omitted. SeaweedFS already uses the bbolt
backend. No database format migration or conversion is performed here.

OUF owns review and maintenance of this local adaptation. Upstream changes
must be evaluated against these exact source inputs; this is not an upstream
release or an assertion that all SeaweedFS dependencies are maintained.

Upstream input SHA256:
- bolt_store.go: 49831a1fc1141f12e97d83fc617fcb82e5b187cf4f1f43e26eba8496c9a7a089
- metrics.go: 2eb9d3dba67f37ba2962233ecb88aeb2ef167439ef5038161dde3d1f99008998
- util.go: bc8fb0b8f9a51ab655babbade157ffcec84ee5a65aecae33c24dd5630c31ed48
- bolt_store_test.go: 59c4ae46cbd747bc36a59d30d04994739443690541f6497e8370333ad596af4d
- LICENSE: 977d08f671b26f63c6e8b9783aa1dc91ba8a01afe1aa10549281a9d388749857
